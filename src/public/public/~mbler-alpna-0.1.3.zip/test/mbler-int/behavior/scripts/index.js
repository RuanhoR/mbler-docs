import {
  GameLib
} from "gameLib"
import {
  regEvent
} from "./lib/event/index"
const game = new GameLib(true);
regEvent(game);